exports.settings = {
    // If you use actual device, can try to set it to the IP address of the server
    // For emulator, 10.0.2.2 refers as the loopback address
    // 127.0.0.1
    serverPath: 'http://10.0.2.2:5000',
}