<section class="book-section">
    <h2>Latest Books</h2>
    <div class="slider-container">
        <div class="book-slider">
            <div class="book-card">
                <img src="book_png/book1.jpg" alt="Book 1">
                <p class="book-title">Create your own</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book2.jpg" alt="Book 2">
                <p class="book-title">Good Sister</p>
                <p class="book-price">RM19.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book3.jpg" alt="Book 3">
                <p class="book-title">Bigger & Better</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book4.jpg" alt="Book 4">
                <p class="book-title">Think Outside</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book5.jpg" alt="Book 5">
                <p class="book-title">Create your own</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book6.jpg" alt="Book 6">
                <p class="book-title">Good Sister</p>
                <p class="book-price">RM19.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book7.jpg" alt="Book 7">
                <p class="book-title">Bigger & Better</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book8.jpg" alt="Book 8">
                <p class="book-title">Think Outside</p>
                <p class="book-price">RM229.20</p>
            </div>
            <!-- 更多书本... -->
            <div class="book-card more">
                <a href="product.php">See More →</a>
            </div>
        </div>
    </div>
</section>

<section class="book-section">
    <h2>Promotion</h2>
    <div class="slider-container">
        <div class="book-slider">
            <div class="book-card">
                <img src="book_png/book1.jpg" alt="Book 1">
                <p class="book-title">Create your own</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book2.jpg" alt="Book 2">
                <p class="book-title">Good Sister</p>
                <p class="book-price">RM19.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book3.jpg" alt="Book 3">
                <p class="book-title">Bigger & Better</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book4.jpg" alt="Book 4">
                <p class="book-title">Think Outside</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book5.jpg" alt="Book 5">
                <p class="book-title">Create your own</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book6.jpg" alt="Book 6">
                <p class="book-title">Good Sister</p>
                <p class="book-price">RM19.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book7.jpg" alt="Book 7">
                <p class="book-title">Bigger & Better</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book8.jpg" alt="Book 8">
                <p class="book-title">Think Outside</p>
                <p class="book-price">RM229.20</p>
            </div>
            <!-- 更多书本... -->
            <div class="book-card more">
                <a href="product.php">See More →</a>
            </div>
        </div>
    </div>
</section>

<section class="book-section">
    <h2>Popular pick</h2>
    <div class="slider-container">
        <div class="book-slider">
            <div class="book-card">
                <img src="book_png/book1.jpg" alt="Book 1">
                <p class="book-title">Create your own</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book2.jpg" alt="Book 2">
                <p class="book-title">Good Sister</p>
                <p class="book-price">RM19.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book3.jpg" alt="Book 3">
                <p class="book-title">Bigger & Better</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book4.jpg" alt="Book 4">
                <p class="book-title">Think Outside</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book5.jpg" alt="Book 5">
                <p class="book-title">Create your own</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book6.jpg" alt="Book 6">
                <p class="book-title">Good Sister</p>
                <p class="book-price">RM19.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book7.jpg" alt="Book 7">
                <p class="book-title">Bigger & Better</p>
                <p class="book-price">RM229.20</p>
            </div>
            <div class="book-card">
                <img src="book_png/book8.jpg" alt="Book 8">
                <p class="book-title">Think Outside</p>
                <p class="book-price">RM229.20</p>
            </div>
            <!-- 更多书本... -->
            <div class="book-card more">
                <a href="product.php">See More →</a>
            </div>
        </div>
    </div>
</section>
