<?php session_start(); 

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'host') {
    die("Access denied. Host only.");
}

include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST;
    $author = $_POST['author'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $uploaded_by = $_SESSION['user_id'];

    $target_dir = "uploads/books/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $file_name = basename($_FILES["cover_image"]["name"]);
    $target_file = $target_dir . time() . "_" . $file_name;

    if (move_uploaded_file($_FILES["cover_image"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO books (title, author, description, category, price, cover_image, uploaded_by)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssdsd", $title, $author, $description, $category, $price, $target_file, $uploaded_by);
        
        if ($stmt->execute()) {
            echo "Book uploaded successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Failed to upload image.";
    }
}
?>
