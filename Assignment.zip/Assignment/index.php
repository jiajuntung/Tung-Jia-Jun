<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale = 1.0">
    <title>TreeBook</title>
    <link rel="stylesheet" href="style.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,opsz,wght@0,6..96,400..900;1,6..96,400..900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Special+Gothic+Expanded+One&family=Tenor+Sans&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

    <body>
       <?php include 'header.php'; ?>

       <main class="content">
            <div class="intro">
                <div class="intro-text">
                    <h2 class="welcome">WELCOME TO</h2>
                    <h1 class="treebook">TreeBook</h1>
                </div>
                <div class="intrologo">
                    <img src="logo/treelogo.png" alt="TreeBook Logo">
                </div>
            </div>

            <div class="searchbox">
                <div class="input-wrapper">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" placeholder="Search books...">
                </div>
                <button>Search</button>
            </div>

            <?php include 'booklist.php'; ?>

       </main>
    </body>
</html>