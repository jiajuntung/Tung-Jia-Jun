<?php
session_start();

// 模拟已登录用户
if (!isset($_SESSION['username'])) {
    $_SESSION['username'] = "Kok Wen Kai";
    $_SESSION['avatar'] = "user.png";
}
?>

<header class="header">
    <div class="logo">
        <img src="logo/logotree.png" alt="TreeBook Logo">
        <span>TreeBook</span>
    </div>

    <nav class="navbar">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Nata+Sans:wght@100..900&display=swap" rel="stylesheet">
        <li><a href="index.php">Home</a></li>
        <li><a href="promotion.php">Promotion</a></li>
        <li><a href="product.php">Product</a></li>
        <li><a href="aboutUs.php">About Us</a></li>
    </nav>

    <div class="menu-toggle"><i class="fa-solid fa-bars fa-xs"></i></div>
    <nav class="menu-navbar">
        <li><a href="index.php">Home</a></li>
        <li><a href="promotion.php">Promotion</a></li>
        <li><a href="product.php">Product</a></li>
        <li><a href="aboutUs.php">About Us</a></li>

        <br>

        <?php if (isset($_SESSION['username'])): ?>
          <div class="menu-user">
                <img src="<?php echo $_SESSION['avatar']; ?>" alt="User" class="avatar">
                <span class="username"><?php echo $_SESSION['username']; ?></span>
            </div>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
            <?php endif;?>
    </nav>

    <div class="overlay" id="overlay"></div>

    <div>
        <div class="user-dropdown">
            <?php if (isset($_SESSION['username'])): ?>
                <img src="<?php echo $_SESSION['avatar']; ?>" alt="User" class="avatar">
                <span class="dropbtn"><?php echo $_SESSION['username']; ?></span>
                <div class="dropdown-content">
                    <a href="settings.php">Settings</a>
                    <a href="logout.php">Logout</a>
                </div>
                
            <?php else: ?>
                <a href="login.php">Login</a>
            <?php endif;?>
        </div>

        <a href="cart.php" class="cart-link"><img src="carts.png" alt="Cart" class="cart"></a>
    </div>
</header>

<script>
  const toggle = document.querySelector('.menu-toggle');
  const menuNavbar = document.querySelector('.menu-navbar');
  const overlay = document.getElementById('overlay');

// Dropdown toggle
  const userDropdown = document.querySelector('.user-dropdown');
  const dropBtn = document.querySelector('.dropbtn');
  const avatar = document.querySelector('.avatar');

  // 点击 username 或 avatar 打开/关闭下拉
  if (userDropdown && dropBtn) {
    dropBtn.addEventListener('click', () => {
      userDropdown.classList.toggle('open');
    });
  }
  if (avatar) {
    avatar.addEventListener('click', () => {
      userDropdown.classList.toggle('open');
    });
  }

  // 点击外部关闭 dropdown
  document.addEventListener('click', (e) => {
    if (!userDropdown.contains(e.target)) {
      userDropdown.classList.remove('open');
    }
  });

  toggle.addEventListener('click', () => {
    menuNavbar.classList.add('active');
    overlay.classList.add('active');
    toggle.style.display = "none";
  });

  overlay.addEventListener('click', () => {
    menuNavbar.classList.remove('active');
    overlay.classList.remove('active');
    toggle.style.display = "block"; // 显示 hamburger
  });
</script>